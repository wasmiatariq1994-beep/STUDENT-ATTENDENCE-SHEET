from flask import Flask, render_template, request, redirect
import csv
from datetime import datetime
import os

app = Flask(__name__)

CSV_FILE = 'attendance.csv'

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        teacher = request.form['teacher']
        course = request.form['course']
        code = request.form['code']
        date = datetime.now().strftime("%Y-%m-%d")

        students = []
        for i in range(1, 5):  # 4 students for example
            name = request.form.get(f'name{i}')
            father = request.form.get(f'father{i}')
            roll = request.form.get(f'roll{i}')
            status = request.form.get(f'status{i}')
            if name and roll:
                students.append([teacher, course, code, date, name, father, roll, status])

        # Save to CSV
        file_exists = os.path.isfile(CSV_FILE)
        with open(CSV_FILE, 'a', newline='') as file:
            writer = csv.writer(file)
            if not file_exists:
                writer.writerow(['Teacher', 'Course', 'Code', 'Date', 'Student', 'Father', 'Roll', 'Status'])
            writer.writerows(students)

        return redirect('/')

    return render_template('index.html')

if __name__ == "__main__":
    app.run(debug=True)
